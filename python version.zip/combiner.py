
x = 'Hello        file1.txt'.split('    ')
print(x)